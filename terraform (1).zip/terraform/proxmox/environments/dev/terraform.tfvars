proxmox_api_url          = "https://10.5.0.5:8006/api2/json"
proxmox_api_token_id     = "terraform@pve!terraform"
proxmox_api_token_secret = "redacted"
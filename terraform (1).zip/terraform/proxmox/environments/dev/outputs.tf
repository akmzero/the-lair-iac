output "vm_id" {
  description = "Proxmox VMID"
  value       = module.ubuntu-dev.vm_id
}

output "vm_name" {
  description = "VM display name"
  value       = module.ubuntu-dev.vm_name
}

output "vm_ipv4_address" {
  description = "IPv4 address assigned to the VM"
  value       = module.ubuntu-dev.ipv4_address
}

output "vm_mac_address" {
  description = "MAC address of the VM's first network interface"
  value       = module.ubuntu-dev.mac_address
}

output "ansible_connection_string" {
  description = "SSH connection string for Ansible inventory"
  value       = "${var.vm_user}@${module.ubuntu-dev.ipv4_address}"
}
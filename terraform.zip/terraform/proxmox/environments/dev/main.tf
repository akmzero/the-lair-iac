locals {
  vms = {
    "1"   = {  }
    "2" = { sockets = 2, cores = 4, memory = 4096 }
  }
}

module "ubuntu-dev" {
  source   = "../../modules/ubuntu-server"
  for_each = local.vms

  name        = "tf-ubuntu-${each.key}"
  target_node = "pve"
  sockets = each.value.sockets
  cores       = each.value.cores
  memory      = each.value.memory
  scsihw  = "virtio-scsi-pci"
  boot = "order=scsi0"
  disk_size   = "20G"
  agent = 1
  os_type = "cloud-init"
  id     = 0
  model  = "virtio"
  bridge = "vmbr1"
  snippet  = "user=local:snippets/ubuntu-baseline.yaml"
  tags        = "ubuntu;tf-managed;dev"
}
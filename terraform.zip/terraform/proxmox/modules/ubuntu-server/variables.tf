variable "name" {
  type        = string
  description = "Display name of the VM"
}

variable "target_node" {
  type        = string
  description = "Cluster node to create the VM on"
}

variable "sockets" {
  type        = number
  description = "Number of CPU Sockets to allocate"
  default     = 2
}

variable "cores" {
  type        = number
  description = "Number of CPU cores to allocate"
  default     = 2
}

variable "memory" {
  type        = number
  description = "RAM in MB"
  default     = 2048
}

variable "disk_size" {
  type        = string
  description = "OS disk size"
  default     = "20G"
}

variable "scsihw" {
  type        = string
  description = "Storage Driver Type"
  default     = "virtio-scsi-pci"
}

variable "boot" {
  type        = string
  description = "VM Boot Device Order"
  default     = "order=scsi0"
}

variable "agent" {
  type        = string
  description = "Guest Agent Activation"
  default     = 1
}

variable "os_type" {
  type        = string
  description = "VM OS"
  default     = "cloud-init"
}

variable "id" {
  type        = string
  description = "Drive ID"
  default     = "0"
}

variable "model" {
  type        = string
  description = "Model of the driver for the VM"
  default     = "virtio"
}

variable "bridge" {
  type        = string
  description = "Network Bridge"
  default     = "vmbr1"
}

variable "tags" {
  type        = string
  description = "Tags for inventory and identification"
  default     = "ubuntu;tf-managed"
}

variable "storage" {
  type        = string
  description = "Storage Pool for VM disks and cloud-init drive"
  default     = "ssdpool"
}

variable "ip_config" {
  type        = string
  description = "Cloud-init IP config ('ip=dhcp' or 'ip=10.5.0.50/24,gw=10.5.0.1')"
  default     = "ip=dhcp"
}

variable "snippet" {
  type        = string
  description = "Snippet for VM"
  default     = "user=local:snippets/ubuntu-baseline.yaml"
}